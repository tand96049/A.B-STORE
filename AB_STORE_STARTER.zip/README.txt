A.B STORE - STARTER WEBSITE

Files:
- index.html: home page
- css/style.css: visual design and responsive layout
- js/app.js: mobile menu and small shared interactions
- other HTML files: starter placeholders for pages linked from the menu

HOW TO USE ON GITHUB:
1. Download and unzip this folder.
2. Open your GitHub repository A.B-STORE.
3. Upload the files and folders from inside AB_STORE_STARTER (not the outer folder itself).
4. Commit changes.
5. In GitHub repository Settings > Pages, make sure Pages is deployed from the correct branch (usually main, / root).
6. Open the published website and refresh.

IMPORTANT:
This is a front-end starter template. Product catalogue, real cart/checkout, Supabase authentication, payment processing, order storage, tracking, and admin settings are NOT active yet. Do not collect real customer payment information until those systems are configured and tested.
