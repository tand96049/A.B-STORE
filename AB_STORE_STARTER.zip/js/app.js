// A.B STORE shared frontend behavior
(() => {
  const burgerBtn = document.getElementById("burgerBtn");
  const mobileMenu = document.getElementById("mobileMenu");

  if (burgerBtn && mobileMenu) {
    burgerBtn.addEventListener("click", () => {
      const isOpen = mobileMenu.classList.toggle("open");
      burgerBtn.setAttribute("aria-expanded", String(isOpen));
      burgerBtn.setAttribute("aria-label", isOpen ? "Close menu" : "Open menu");
    });

    mobileMenu.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        mobileMenu.classList.remove("open");
        burgerBtn.setAttribute("aria-expanded", "false");
        burgerBtn.setAttribute("aria-label", "Open menu");
      });
    });
  }

  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  // This starter counter reads a local cart count if one has been saved.
  // It does not submit orders or connect to a payment provider.
  const cartCount = document.getElementById("cartCount");
  if (cartCount) {
    try {
      const savedCart = JSON.parse(localStorage.getItem("ab_store_cart") || "[]");
      cartCount.textContent = savedCart.reduce((sum, item) => sum + Number(item.quantity || 1), 0);
    } catch (_) {
      cartCount.textContent = "0";
    }
  }
})();
